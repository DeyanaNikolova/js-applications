function attachEvents() {
    document.querySelector('#submit').addEventListener('click', onSubmit);
    document.querySelector('#refresh').addEventListener('clock', onRefresh);

}

let url = 'http://localhost:3030/jsonstore/messenger';

function onSubmit() {
 let authorName = document.querySelector('[name="author"]');
 let content = document.querySelector('[name="content"]');

 if(!authorName.value || !content.valie){
    return
 }
 fetch(url, {
    method: 'POST',
    headers: { 'Contemt-type': 'application/json'},
    body: JSON.stringify({
        author: authorName.value.trim(),
        content: content.value.trim()
    })
 })
 .then(response =>{
    if (response.ok == false) {
        throw new Error('Error creating new record');
    }
    return response.json();
 })
 .catch(err => alert(err))

 authorName.value = '';
 content.value = '';
}


function onRefresh() {
    fetch(url)
        .then(response => {
            if (response.ok == false) {
                throw new Error('Error');
            }
            return response.json();
        })
        .then(data => {
            const messagesElement = document.querySelector('#messages');
            let coments = [];
            Object.values(data).forEach(u => coments.push(`${u.author}: ${u.content}`));
            messagesElement.value = coments.join('\n');
        })
        .catch(err => alert(err))
}

attachEvents();